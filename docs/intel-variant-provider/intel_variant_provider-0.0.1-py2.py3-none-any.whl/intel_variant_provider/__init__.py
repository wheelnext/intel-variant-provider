"""A wheel variant provider with properties specific to Intel GPU (XPU)"""

from __future__ import annotations

__version__ = "0.0.1"
