# Copyright (c) 2025 Intel Corporation

from __future__ import annotations

import platform
import warnings
from dataclasses import dataclass
from functools import cache

from intel_variant_provider.devices import *
from intel_variant_provider.ze import *

VariantNamespace = str
VariantFeatureName = str
VariantFeatureValue = str


@dataclass(frozen=True)
class VariantFeatureConfig:
    name: str

    # Acceptable values in priority order
    values: list[str]
    multi_value: bool = False


def getAllUniqueDeviceIPs():
    pci_vendor_id_intel = 0x8086
    devips = []
    try:
        desc = c_ze_init_driver_type_desc_t()
        desc.flags = ZE_INIT_DRIVER_TYPE_FLAG_GPU
        drivers = zeInitDrivers(desc)

        for driver in drivers:
            devices = zeDeviceGet(driver)
            for device in devices:
                devip = c_ze_device_ip_version_ext_t()
                props = zeDeviceGetProperties(device, [devip])
                if props.vendorId == pci_vendor_id_intel:
                    devip = IntelDeviceIp(devip.ipVersion)
                    for ip in devip.get_all_compat_ips():
                        # We must return list of unique IPs as a requirement
                        # of variantlib.
                        if ip not in devips:
                            devips.append(ip)
    except Exception as e:
        warnings.warn(f"Intel driver stack not installed or malfunctions: {e}", UserWarning, stacklevel=1)
    return devips


class IntelVariantPlugin:
    namespace = "intel"
    dynamic = False

    @classmethod
    @cache
    def generate_all_device_ips(cls) -> list[str] | None:
        if platform.system() not in ["Linux", "Windows"]:
            warnings.warn(f"Unsupported OS: {system}", UserWarning, stacklevel=1)
            return []

        devip = os.getenv("INTEL_VARIANT_PROVIDER_FORCE_DEVICE_IP")
        if devip:
            unique_devips = [devip]
        else:
            unique_devips = getAllUniqueDeviceIPs()

        devips = []
        known_ips = get_all_known_ips()
        for ip in unique_devips:
            # Filter out devices which IPs are not explicitly
            # known to plugin. This gives consistency with the
            # check in validate_property().
            if ip not in known_ips:
                warnings.warn(f"Intel device with {ip} device IP is filtered out as not known to plugin)")
            else:
                devips.append(ip)

        if not devips:
            warnings.warn("No Intel GPU detected", UserWarning, stacklevel=1)
        return devips

    @classmethod
    def get_supported_configs(cls) -> list[VariantFeatureConfig]:
        keyconfigs: list[VariantFeatureConfig] = []

        if devips := cls.generate_all_device_ips():
            keyconfigs.append(
                VariantFeatureConfig(
                    name="device_ip",
                    values=devips,
                    multi_value=True,
                    )
                )

        return keyconfigs

    @classmethod
    def get_all_configs(cls) -> list[VariantFeatureConfig]:
        return [
            VariantFeatureConfig(
                name="device_ip",
                values=get_all_known_ips(),
                multi_value=True,
            ),
        ]

if __name__ == "__main__":
    plugin = IntelVariantPlugin()
    print(plugin.get_supported_configs())
